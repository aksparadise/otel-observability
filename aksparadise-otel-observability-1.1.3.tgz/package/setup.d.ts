// src/setup.d.ts
// ─────────────────────────────────────────────────────────────────────────────
//  Auto-Detection Setup Types — @aksparadise/otel-observability
// ─────────────────────────────────────────────────────────────────────────────

import { NestJSLogger } from './nestjs-logger';

export interface SetupOptions {
    /** Enable auto-detection of framework (default: true) */
    autoDetect?: boolean;
    /** Enable console output (default: true) */
    enableConsoleOutput?: boolean;
    /** Enable OTel output (default: true) */
    enableOtelOutput?: boolean;
    /** Enable console monkeypatching (default: true) */
    enableMonkeypatch?: boolean;
    /** Enable colored console output (default: true) */
    consoleColors?: boolean;
    /** Show metadata in production (default: false) */
    showMetadataInProduction?: boolean;
    /** Force framework detection (default: auto) */
    framework?: 'nestjs' | 'express' | 'nextjs' | 'vanilla';
}

export interface SetupResult {
    /** Detected framework */
    framework: string;
    /** Framework-specific logger instance */
    logger?: NestJSLogger | null;
    /** NestJS-specific setup function */
    setupNestJS?: (app: any) => void;
    /** Express middleware */
    middleware?: (req: any, res: any, next: any) => void;
}

/**
 * Auto-detect and configure complete observability setup
 */
export declare const setup: (options?: SetupOptions) => SetupResult;

/**
 * Framework-specific setup helpers
 */
export declare const setupNestJS: () => SetupResult;
export declare const setupExpress: () => SetupResult;
export declare const setupNextJS: () => SetupResult;

export default setup;
