export interface NestJSLoggerOptions {
    log?: boolean;
    error?: boolean;
    warn?: boolean;
    debug?: boolean;
    verbose?: boolean;
}

export declare class NestJSLogger {
    constructor(options?: NestJSLoggerOptions);
    log(message: any, context?: string): void;
    error(message: any, trace?: string, context?: string): void;
    warn(message: any, context?: string): void;
    debug(message: any, context?: string): void;
    verbose(message: any, context?: string): void;
    setLogLevels(levels: string[]): void;
}
